
package Marketplace;

/**
 * Represents an abstract product in the marketplace.
 * @author 
 * Gopal Vulli
 */
public abstract class Product {
    private String name;
    private double weight;      // stock in kg
    private double pricePerKg;

    /**
     * Constructor for product.
     */
    public Product(String name, double weight, double pricePerKg) {
        this.name = name;
        this.weight = Math.max(0.0, weight);
        this.pricePerKg = Math.max(0.0, pricePerKg);
    }

    /** @return product name */
    public String getName() {
        return name;
    }

    /** Set product weight (stock). Negative values are clamped to 0. */
    public void setWeight(double weight) {
        this.weight = Math.max(0.0, weight);
    }

    /** @return current stock weight in kg */
    public double getWeight() {
        return weight;
    }

    /** @return price per kg */
    public double getPricePerKg() {
        return pricePerKg;
    }

    /**
     * Calculate price (pricePerKg * weight).
     * @return total price for current stock (double)
     */
    public abstract double calculatePrice();

    @Override
    public String toString() {
        return String.format("%s, Weight: %.2f kg, Price: $%.2f/kg", name, weight, pricePerKg);
    }
}


