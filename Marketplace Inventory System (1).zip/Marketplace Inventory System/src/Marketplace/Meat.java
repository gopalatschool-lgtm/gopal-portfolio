
package Marketplace;

/**
 * Meat product. 
 */
public class Meat extends Product {
    private String cutType;

    /**
     * Constructor for Meat class
     */
    public Meat(String name, double weight, double pricePerKg, String cutType) {
        super(name, weight, pricePerKg);
        this.cutType = cutType;
    }

    /**
     * Calculate price for current stock.
     * @return total price for current stock
     */
    @Override
    public double calculatePrice() {
        return getPricePerKg() * getWeight();
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", Type: Meat, Cut: %s", cutType);
    }
}

