
package Marketplace;

/**
 * Represents an item inside a user's cart.
 */
public class CartItem {
    private Product product;
    private double quantity;   
    private double price;      

    /**
     * Constructor for CartItem class
     */
    public CartItem(Product product, double quantity) {
        this.product = product;
        this.quantity = Math.max(0.0, quantity);
        this.price = product.getPricePerKg();
    }

    /** @return product reference */
    public Product getProduct() {
        return product;
    }

    /** @return quantity in kg */
    public double getQuantity() {
        return quantity;
    }

    /**
     * Calculate total price for this cart item using the snapshot pricePerKg.
     * @return total price for this cart item
     */
    public double calculatePrice() {
        return price * quantity;
    }

    @Override
    public String toString() {
        return String.format("%s - %.2f kg @ $%.2f/kg, Total: $%.2f",
                product.getName(), quantity, price, calculatePrice());
    }
}
