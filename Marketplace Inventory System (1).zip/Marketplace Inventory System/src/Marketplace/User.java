
package Marketplace;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 * User roles: view inventory, add and remove items from cart, view cart, checkout, logout.
 */
public class User implements MarketPlaceAccess {
    private ArrayList<Product> inventory;      
    private ArrayList<CartItem> cart;
    private Scanner input;

    /**
     * 
     * Constructor for user class
     */
    public User(ArrayList<Product> inventory, Scanner scanner) {
        this.inventory = inventory;
        this.input = scanner;
        this.cart = new ArrayList<>();
    }

    /**
     * Interactive user menu providing required capabilities.
     */
    @Override
    public void showMenu() {
        while (true) {
            System.out.println("\n--- User Menu ---");
            System.out.println("1. View Inventory");
            System.out.println("2. Add to Cart");
            System.out.println("3. Remove from Cart");
            System.out.println("4. View Cart");
            System.out.println("5. Checkout");
            System.out.println("6. Logout");
            System.out.print("Choose: ");
            String choice = input.nextLine().trim();
            switch (choice) {
                case "1":
                    viewInventory();
                    break;
                case "2":
                    addToCartInteractive();
                    break;
                case "3":
                    removeFromCartInteractive();
                    break;
                case "4":
                    viewCart();
                    break;
                case "5":
                    checkoutInteractive();
                    break;
                case "6":
                    logout();
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    /** Print inventory items and details. */
    public void viewInventory() {
        if (inventory.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        System.out.println("\n--- Inventory ---");
        for (Product p : inventory) {
            System.out.println(p.toString());
        }
    }

    /** Interactive add to cart with validation against stock. */
    private void addToCartInteractive() {
        System.out.print("Enter product name: ");
        String name = input.nextLine().trim();
        Product found = null;
        for (Product p : inventory) {
            if (p.getName().equalsIgnoreCase(name)) {
                found = p;
                break;
            }
        }
        if (found == null) {
            System.out.println("Product not found.");
            return;
        }
        double quantity = readNonNegativeDouble("Enter quantity (kg): ");
        if (quantity <= 0.0) {
            System.out.println("Quantity must be positive.");
            return;
        }
        if (quantity > found.getWeight()) {
            System.out.printf("Not enough stock. Available: %.2f kg%n", found.getWeight());
            return;
        }

        // If product already in cart, increment quantity
        for (CartItem ci : cart) {
            if (ci.getProduct().getName().equalsIgnoreCase(found.getName())) {
                // sum the quantities (create new CartItem to update snapshot price)
                double newQty = ci.getQuantity() + quantity;
                cart.remove(ci);
                cart.add(new CartItem(found, newQty));
                System.out.printf("Added %.2f kg of %s to the cart. (Now %.2f kg)%n",
                        quantity, found.getName(), newQty);
                return;
            }
        }

        cart.add(new CartItem(found, quantity));
        System.out.printf("Added %.2f kg of %s to the cart.%n", quantity, found.getName());
    }

    /** Interactive remove from cart by product name. */
    private void removeFromCartInteractive() {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }
        System.out.print("Enter product name to remove from cart: ");
        String name = input.nextLine().trim();
        Iterator<CartItem> it = cart.iterator();
        boolean removed = false;
        while (it.hasNext()) {
            CartItem ci = it.next();
            if (ci.getProduct().getName().equalsIgnoreCase(name)) {
                it.remove();
                removed = true;
            }
        }
        System.out.println(removed ? "Removed from cart." : "Item not found in cart.");
    }

    /** View current cart and total. */
    public void viewCart() {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }
        System.out.println("\n--- Cart ---");
        double total = 0.0;
        for (CartItem ci : cart) {
            System.out.println(ci.toString());
            total += ci.calculatePrice();
        }
        System.out.printf("Total Payment: $%.2f%n", total);
    }

    /** Interactive checkout: confirm purchase, update inventory, remove out-of-stock items. */
    private void checkoutInteractive() {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }
        System.out.println("\n--- Checkout ---");
        double total = 0.0;
        for (CartItem ci : cart) {
            System.out.println(ci.toString());
            total += ci.calculatePrice();
        }
        System.out.printf("Total Payment: $%.2f%n", total);
        System.out.print("Confirm purchase? (y/n): ");
        String confirm = input.nextLine().trim().toLowerCase();
        if (!confirm.startsWith("y")) {
            System.out.println("Checkout cancelled.");
            return;
        }

        // Update inventory: subtract quantities and remove out-of-stock items
        for (CartItem ci : cart) {
            Product p = ci.getProduct();
            double qty = ci.getQuantity();
            p.setWeight(p.getWeight() - qty);
        }

        // Remove items with weight <= 0
        Iterator<Product> pit = inventory.iterator();
        while (pit.hasNext()) {
            Product p = pit.next();
            if (p.getWeight() <= 0.0) {
                pit.remove();
            }
        }

        cart.clear();
        System.out.println("Thank you for your purchase!");
    }

    /** Logout (public method) */
    public void logout() {
        System.out.println("User logged out.");
    }

    /** Utility: read a non-negative double from scanner with prompt. */
    private double readNonNegativeDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            try {
                double val = Double.parseDouble(line);
                if (val < 0) {
                    System.out.println("Value must be non-negative.");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number; try again.");
            }
        }
    }
}
