
package Marketplace;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 * Manager role: can add, remove, search, view inventory, adjust weight, and logout.
 */
public class Manager implements MarketPlaceAccess {
    private ArrayList<Product> inventory;
    private Scanner sc;

    /**
     * Constructor for Manager class
     */
    public Manager(ArrayList<Product> inventory, Scanner scanner) {
        this.inventory = inventory;
        this.sc = scanner;
    }

    /**
     * Interactive manager menu. 
     */
    @Override
    public void showMenu() {
        while (true) {
            System.out.println("\n--- Manager Menu ---");
            System.out.println("1. View Inventory");
            System.out.println("2. Add Product");
            System.out.println("3. Remove Product");
            System.out.println("4. Adjust Weight");
            System.out.println("5. Search Product");
            System.out.println("6. Logout");
            System.out.print("Choose: ");
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1":
                    viewInventory();
                    break;
                case "2":
                    addProductInteractive();
                    break;
                case "3":
                    removeProductInteractive();
                    break;
                case "4":
                    adjustWeightInteractive();
                    break;
                case "5":
                    searchProductInteractive();
                    break;
                case "6":
                    logout();
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    /** Print all products in inventory. */
    public void viewInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Inventory is empty.");
            return;
        }
        System.out.println("\n--- Inventory ---");
        for (Product p : inventory) {
            System.out.println(p.toString());
        }
    }

    /** Interactive add product as per assignment example. */
    private void addProductInteractive() {
        System.out.print("Enter product name: ");
        String name = sc.nextLine().trim();
        double weight = readNonNegativeDouble("Enter weight (kg): ");
        double price = readNonNegativeDouble("Enter price per kg: ");
        System.out.println("Enter product type (1: Vegetable, 2: Fruit, 3: Meat): ");
        String type = sc.nextLine().trim();
        Product p = null;
        switch (type) {
            case "1":
                System.out.print("Is it organic? (y/n): ");
                boolean organic = sc.nextLine().trim().toLowerCase().startsWith("y");
                p = new Vegetable(name, weight, price, organic);
                break;
            case "2":
                System.out.print("Enter season: ");
                String season = sc.nextLine().trim();
                p = new Fruit(name, weight, price, season);
                break;
            case "3":
                System.out.print("Enter cut type: ");
                String cut = sc.nextLine().trim();
                p = new Meat(name, weight, price, cut);
                break;
            default:
                System.out.println("Invalid type. Aborting add.");
                return;
        }
        inventory.add(p);
        System.out.println("Product added successfully!");
    }

    /** Interactive remove product by name (removes all matching names). */
    private void removeProductInteractive() {
        System.out.print("Enter product name to remove: ");
        String name = sc.nextLine().trim();
        Iterator<Product> it = inventory.iterator();
        boolean removed = false;
        while (it.hasNext()) {
            Product p = it.next();
            if (p.getName().equalsIgnoreCase(name)) {
                it.remove();
                removed = true;
            }
        }
        System.out.println(removed ? "Product(s) removed." : "No product found by that name.");
    }

    /** Interactive adjust weight for a product. */
    private void adjustWeightInteractive() {
        System.out.print("Enter product name to adjust weight: ");
        String name = sc.nextLine().trim();
        Product found = null;
        for (Product p : inventory) {
            if (p.getName().equalsIgnoreCase(name)) {
                found = p;
                break;
            }
        }
        if (found == null) {
            System.out.println("Product not found.");
            return;
        }
        double newWeight = readNonNegativeDouble("Enter new weight (kg): ");
        found.setWeight(newWeight);
        System.out.println("Weight updated.");
        if (found.getWeight() <= 0.0) {
            System.out.println("Product is out of stock; consider removing it.");
        }
    }

    /** search product by name. */
    private void searchProductInteractive() {
        System.out.print("Enter product name to search: ");
        String name = sc.nextLine().trim();
        boolean foundAny = false;
        for (Product p : inventory) {
            if (p.getName().equalsIgnoreCase(name)) {
                System.out.println(p.toString());
                foundAny = true;
            }
        }
        if (!foundAny) {
            System.out.println("No matching products.");
        }
    }

    /** Remove a specific product object from inventory (public method per UML). */
    public void removeProduct(Product product) {
        inventory.remove(product);
    }

    /** Add a product to inventory (public method per UML). */
    public void addProduct(Product product) {
        inventory.add(product);
    }

    /** Find product by name (public method per UML). */
    public Product searchProduct(String name) {
        for (Product p : inventory) {
            if (p.getName().equalsIgnoreCase(name)) return p;
        }
        return null;
    }

    /** Adjust weight for a product object (public method per UML). */
    public void adjustWeight(Product product, double newWeight) {
        product.setWeight(newWeight);
    }

    /** Logout method */
    public void logout() {
        System.out.println("Manager logged out.");
    }

    /** Utility: read a non-negative double from scanner with prompt. */
    private double readNonNegativeDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                double val = Double.parseDouble(line);
                if (val < 0) {
                    System.out.println("Value must be non-negative.");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number; try again.");
            }
        }
    }
}
