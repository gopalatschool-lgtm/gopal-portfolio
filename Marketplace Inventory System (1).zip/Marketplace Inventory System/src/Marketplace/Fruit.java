
package Marketplace;

/**
 * Fruit product. 
 */
public class Fruit extends Product {
    private String season;

    /**
     * Constructor for fruit class
     */
    public Fruit(String name, double weight, double pricePerKg, String season) {
        super(name, weight, pricePerKg);
        this.season = (season == null) ? "" : season;
    }

    /**
     * Calculate price.
     * @return total price for current stock
     */
    @Override
    public double calculatePrice() {
        return getPricePerKg() * getWeight();
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", Type: Fruit, Season: %s", season);
    }
}
