
package Marketplace;

public interface MarketPlaceAccess {
    /**
     * Show menu for each role.
     */
    void showMenu();
}