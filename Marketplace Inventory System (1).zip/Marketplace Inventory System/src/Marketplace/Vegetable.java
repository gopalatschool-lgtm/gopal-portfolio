package Marketplace;

/**
 * Vegetable product.
 */
public class Vegetable extends Product {
    private boolean isOrganic;

    /**
     * Constructor for Vegetable class
     */
    public Vegetable(String name, double weight, double pricePerKg, boolean isOrganic) {
        super(name, weight, pricePerKg);
        this.isOrganic = isOrganic;
    }

    /**
     * Calculate price for the current stock.
     * @return total price
     */
    @Override
    public double calculatePrice() {
        double base = getPricePerKg() * getWeight();
        return isOrganic ? base * 1.10 : base;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", Type: Vegetable, Organic: %s", isOrganic ? "Yes" : "No");
    }
}
