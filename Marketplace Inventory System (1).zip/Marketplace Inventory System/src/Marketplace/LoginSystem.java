
package Marketplace;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Login system and program entry point.
 */
public class LoginSystem {
    private static final String MANAGER_USERNAME = "admin";
    private static final String MANAGER_PASSWORD = "password123";
    private static final String USER_USERNAME = "customer";
    private static final String USER_PASSWORD = "guest";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Product> inventory = new ArrayList<>();

        // Optional: sample inventory to start with, done so that methods can be used when the code is run.
        inventory.add(new Fruit("Apple", 10.0, 4.0, "Summer"));
        inventory.add(new Vegetable("Carrot", 8.0, 2.5, false));
        inventory.add(new Meat("Chicken Breast", 5.0, 6.0, "Breast"));

        System.out.println("=== Welcome to the Marketplace Inventory System ===");

        while (true) {
            System.out.println("\n1. Login as Manager");
            System.out.println("2. Login as User");
            System.out.println("3. Exit");
            System.out.print("Choose: ");
            String choice = sc.nextLine().trim();
            if (choice.equals("1")) {
                if (login(sc, MANAGER_USERNAME, MANAGER_PASSWORD)) {
                    Manager manager = new Manager(inventory, sc);
                    manager.showMenu();
                } else {
                    System.out.println("Authentication failed.");
                }
            } else if (choice.equals("2")) {
                if (login(sc, USER_USERNAME, USER_PASSWORD)) {
                    User user = new User(inventory, sc);
                    user.showMenu();
                } else {
                    System.out.println("Authentication failed.");
                }
            } else if (choice.equals("3")) {
                System.out.println("Exiting system. Goodbye!");
                break;
            } else {
                System.out.println("Invalid option.");
            }
        }

        sc.close();
    }

    /** Simple login */
    private static boolean login(Scanner sc, String expectedUser, String expectedPass) {
        System.out.print("Username: ");
        String u = sc.nextLine().trim();
        System.out.print("Password: ");
        String p = sc.nextLine().trim();
        return u.equals(expectedUser) && p.equals(expectedPass);
    }
}
